MONGO_URI = "paste your mongodb localhost server"

DATABASE_NAME="Todo" 
